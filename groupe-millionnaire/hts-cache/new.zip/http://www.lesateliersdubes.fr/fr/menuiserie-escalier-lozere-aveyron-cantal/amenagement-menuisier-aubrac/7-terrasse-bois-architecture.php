
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Terrasse bois en Loz&egrave;re, Aveyron, Cantal</title>
        <meta http-equiv="content-language" content="fr" />
		<meta name="language" content="fr" />
		<meta name="description" content="Conçue à l'épreuve du temps, votre terrasse bois doit être en harmonie avec l'architecture intérieur de votre maison." />
		<meta name="keywords" content="menuiserie, Loz&egrave;re, menuisier, escalier, Loz&egrave;re, Aveyron, Cantal, portes, fen&ecirc;tre, Aubrac" />
		<meta name="revisit-after" content="7 days">
   		<meta name="google-site-verification" content="KDWeMTfOQI5L5sKUBNmHHe4_i2mojx5T8Akl4sLhuA0" />
        <meta name="google-site-verification" content="oz8E792oakYBbgPpCDi5TSGLs7k6VDlZAxuHtGUt0vU" />
		<meta name="robots" content="index, follow">
		<meta name="author" content="Cyberiance SARL">
		<meta name="copyright" content="Cyberiance SARL 2021">
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
        <script type="text/javascript" src="/js/jquery/fancybox/jquery.fancybox.js"></script>
        <script type="text/javascript" src="/js/jquery/fadealicious/javascript/slider-fadelicious.js"></script>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.0.7/js/swiper.min.js"></script>
				<link rel="stylesheet" media="screen" href="/theme/default/knacss.css" />
				<link rel="stylesheet" media="screen" href="/theme/default/style.css" />
        <link rel="stylesheet" media="screen" href="/js/jquery/fancybox/jquery.fancybox.css" />
        <link rel="stylesheet" media="screen" href="/js/jquery/fadealicious/css/slider-fadelicious2.css" />
        <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Marvel">
				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.0.7/css/swiper.min.css">

				<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-111111524-1', 'auto');
	  ga('send', 'pageview');
	</script>

	<script type="text/javascript">

		$(document).ready(function(){

			$('#target').click(function() {
				ga('send', 'event', 'Afficher le numéro de téléphone', 'click', 'image');
			});

			$('#ask-devis').click(function() {
				ga('send', 'event', 'Demander un devis', 'click', 'image');
			});


		});

	</script>

    </head>

    <body>
   		<div style="width:960px; margin: 0 auto;position:relative;text-align:right;color:#FFF;padding-top:1em;">
                <a style='color:#FFF;' href="http://www.lesateliersdubes.fr"><!--<img src="/theme/default/img/dr_fr.png" />-->FR</a> |
                <a style='color:#FFF;' href="http://www.lesateliersdubes.fr/en/"><!--<img src="/theme/default/img/dr_en.png" />-->EN</a>
        </div>
    	<div id="container">
			<div id="header" class="pam pb0">
				<div class="box-entete pas">
					<a href="http://www.lesateliersdubes.fr" class="logo" title="Menuiserie et agencement Lozère">
						<img src="/theme/default/img/logo_atelier.png" title="Menuiserie et agencement Lozère" class="logo-du-bes" />
					</a>
					<div class="actualites">
						<a href="http://www.la-foire-de-lozere.com/" target="_blank" title="En savoir + sur la foire de Lozère">
							
								
				            						</a>
					</div>
				</div>
				<!-- <div class="txtcenter pas">
					<a href="http://www.lesateliersdubes.fr" class="logo" title="Menuiserie et agencement Lozère">
						<img src="/theme/default/img/logo_atelier.png" title="Menuiserie et agencement Lozère"/>
					</a>
				</div> -->
			    <ul class="menu flex-container flex-justify-center">
						<li><a href="http://www.lesateliersdubes.fr " title="Menuiserie et agencement Lozère"><img src="/theme/default/img/icone_home.png" title="Accueil" title="Menuiserie et agencement Lozère"/></a></li>
						<li><a class=" art7 ord1" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/3-escaliers-bois-traditionnel-contemporain.php">Escaliers</a></li><li><a class=" art7 ord2" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/4-menuiserie-porte-meuble.php">Menuiserie</a></li><li><a class=" art7 ord3" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/71-amenagement-cuisine-lozere.php">Cuisine</a></li><li><a class=" art7 ord4" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/5-amenagement-dressing-rangement.php">Am&eacute;nagement</a></li><li><a class=" art7 ord5" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/72-agencemenent-professionnel-lozere-cantal-aveyron.php">Pour les pros</a></li><li><a class=" art7 ord6 selected" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/7-terrasse-bois-architecture.php">Terrasse bois</a></li><li><a class=" art7 ord7" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/6-patrimoine-architecture-lozere-aveyron.php">Patrimoine</a></li><li><a class=" art7 ord8" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/73-metallerie.php">M&eacute;tallerie</a></li>            	</ul>
       		</div>

			<div class="border-head"></div>
			<!-- 			
							
			             -->

            <div class="content pal">
														<div class="bab-gallery"><div class="swiper-container"><div class="swiper-wrapper"><div class="swiper-slide"><img src="/upload/galeries/galerie7/maxi/20161125-162117.-121157.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie7/maxi/img-3265.-051502.JPG" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie7/maxi/img-3255.-051700.JPG" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie7/maxi/img-3263.-051637.JPG" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie7/maxi/img-3261.-051545.JPG" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie7/maxi/img-3260.-051645.JPG" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie7/maxi/phone-115-a.-034031.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie7/maxi/phone-283.-034039.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie7/maxi/phone-114.-034046.jpg" alt="" /></div></div><div class="swiper-pagination"></div></div></div><div class="bab_contenu_article"><h1>Terrasse bois en Loz&egrave;re, dans le Cantal ou l&#039;Aveyron</h1><p>La terrasse en bois est un &eacute;l&eacute;gant moyen de prolonger votre int&eacute;rieur sur l'ext&eacute;rieur afin de profiter d'une&nbsp;agr&eacute;able journ&eacute;e d'hiver ensoleill&eacute;e ou d'un beau soir d'&eacute;t&eacute;.</p>
<p>Elle doit &ecirc;tre con&ccedil;ue&nbsp;&agrave; l'&eacute;preuve du temps et doit&nbsp;s'int&eacute;grer&nbsp;harmonieusement &agrave; l'architecture de votre maison, de votre piscine ou de votre restaurant.</p>
<p>Voici quelques essences utilis&eacute;es pour la construction d'une terrasse en bois :</p>
<ul>
<li>ip&eacute; (une valeur s&ucirc;re qui a fait ses preuves)</li>
<li>fr&ecirc;ne thermo-chauff&eacute;</li>
<li>pin douglas / m&eacute;l&egrave;ze</li>
</ul>
<p>En compl&eacute;ment de votre terrasse bois, nous pouvons y assortir tous les am&eacute;nagements de jardin en bois :</p>
<ul>
<li>pergola</li>
<li>jardini&egrave;res</li>
<li>mobilier de jardin (transat, table...)</li>
</ul><div class="clear"></div></div>
							<footer class="">
								<div class="grid-3 flex-align-center">
									<div class="txtcenter">
										<a id="ask-devis" class="btn" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/13-contact-acces.php">Demande de devis gratuit</a>
									</div>
									<div class="txtcenter">
										<span id="target" class="btn" href="">
											<span class="title">Téléphone</span>
											<a href="tel:+33 (0)4 66 45 90 54">+33 (0)4 66 45 90 54</a></span>
									</div>
									<div class="txtcenter">
										<a id="contact" class="btn" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/13-contact-acces.php">Contact</a>
									</div>
								</div>
								
								<address class="txtcenter">
									<span class="adrr">Les Ateliers du Bès  |  Route d’Aubrac - 48260 Nasbinals - Lozère  |  FRANCE  </span>
								</address>

							</footer>
           	</div>

            <div class="footer txtcenter"><a href="/fr/menuiserie-escalier-lozere-aveyron-cantal/menuisier-lozere-aveyron-cantal/9-artisan-menuisier.php">Artisan-menuisier</a> | <a href="/fr/menuiserie-escalier-lozere-aveyron-cantal/menuisier-lozere-aveyron-cantal/10-liens-partenaires.php">Liens &amp; partenaires</a> | <a href="/fr/menuiserie-escalier-lozere-aveyron-cantal/menuisier-lozere-aveyron-cantal/14-mentions-legales.php">Mentions l&eacute;gales</a>

            </div>

        </div>
    <span id="stamp"><a title="Création et hébergement de sites internet à Pontarlier, Besançon et Morteau, dans le Doubs, le Jura, la Franche-Comté et en Alsace" target="_blank" href="http://www.cyberiance.com" >Création site Cyberiance</a></span>
	</body>
   <script type="text/javascript">
	$(document).ready(function() {
		$(".fancybox").fancybox({
			padding : 2
		});

		$('#target').click(function(){
			$('#target .title').css('display', 'none');
			$('#target a').css('display','inline-block');
		});

		var mySwiper = new Swiper ('.swiper-container', {
      // Optional parameters
			slidesPerView : 'auto',
			effect :'fade',
			grabCursor : true,
			autoplay : true,
			speed : 800,
			pagination: {
    		el : '.swiper-pagination',
    		type : 'bullets',
				clickable : true,
				hideOnClick : true,
				bulletActiveClass : 'swiper-pagination-bullet-active-green'
  		},

		})

	});
</script>
</html>
