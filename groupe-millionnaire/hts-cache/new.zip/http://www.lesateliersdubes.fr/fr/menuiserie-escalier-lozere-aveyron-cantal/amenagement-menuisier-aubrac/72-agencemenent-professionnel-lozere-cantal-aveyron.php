
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Agencement professionnel Loz&egrave;re Cantal Aveyron</title>
        <meta http-equiv="content-language" content="fr" />
		<meta name="language" content="fr" />
		<meta name="description" content="Menuiserie en Loz&egrave;re,  implant&eacute;e &agrave; Nasbinals dans l&#039;Aubrac, pr&egrave;s de l&#039;Aveyron et du cantal. R&eacute;alisation de tous travaux de menuiserie en bois int&eacute;rieure et ext&eacute;rieure, escalier, portes et fen&ecirc;tre bois, terrasse, agencement et am&eacute;nagement par un artisan-menuisier" />
		<meta name="keywords" content="menuiserie, Loz&egrave;re, menuisier, escalier, Loz&egrave;re, Aveyron, Cantal, portes, fen&ecirc;tre, Aubrac" />
		<meta name="revisit-after" content="7 days">
   		<meta name="google-site-verification" content="KDWeMTfOQI5L5sKUBNmHHe4_i2mojx5T8Akl4sLhuA0" />
        <meta name="google-site-verification" content="oz8E792oakYBbgPpCDi5TSGLs7k6VDlZAxuHtGUt0vU" />
		<meta name="robots" content="index, follow">
		<meta name="author" content="Cyberiance SARL">
		<meta name="copyright" content="Cyberiance SARL 2021">
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
        <script type="text/javascript" src="/js/jquery/fancybox/jquery.fancybox.js"></script>
        <script type="text/javascript" src="/js/jquery/fadealicious/javascript/slider-fadelicious.js"></script>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.0.7/js/swiper.min.js"></script>
				<link rel="stylesheet" media="screen" href="/theme/default/knacss.css" />
				<link rel="stylesheet" media="screen" href="/theme/default/style.css" />
        <link rel="stylesheet" media="screen" href="/js/jquery/fancybox/jquery.fancybox.css" />
        <link rel="stylesheet" media="screen" href="/js/jquery/fadealicious/css/slider-fadelicious2.css" />
        <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Marvel">
				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.0.7/css/swiper.min.css">

				<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-111111524-1', 'auto');
	  ga('send', 'pageview');
	</script>

	<script type="text/javascript">

		$(document).ready(function(){

			$('#target').click(function() {
				ga('send', 'event', 'Afficher le numéro de téléphone', 'click', 'image');
			});

			$('#ask-devis').click(function() {
				ga('send', 'event', 'Demander un devis', 'click', 'image');
			});


		});

	</script>

    </head>

    <body>
   		<div style="width:960px; margin: 0 auto;position:relative;text-align:right;color:#FFF;padding-top:1em;">
                <a style='color:#FFF;' href="http://www.lesateliersdubes.fr"><!--<img src="/theme/default/img/dr_fr.png" />-->FR</a> |
                <a style='color:#FFF;' href="http://www.lesateliersdubes.fr/en/"><!--<img src="/theme/default/img/dr_en.png" />-->EN</a>
        </div>
    	<div id="container">
			<div id="header" class="pam pb0">
				<div class="box-entete pas">
					<a href="http://www.lesateliersdubes.fr" class="logo" title="Menuiserie et agencement Lozère">
						<img src="/theme/default/img/logo_atelier.png" title="Menuiserie et agencement Lozère" class="logo-du-bes" />
					</a>
					<div class="actualites">
						<a href="http://www.la-foire-de-lozere.com/" target="_blank" title="En savoir + sur la foire de Lozère">
							
								
				            						</a>
					</div>
				</div>
				<!-- <div class="txtcenter pas">
					<a href="http://www.lesateliersdubes.fr" class="logo" title="Menuiserie et agencement Lozère">
						<img src="/theme/default/img/logo_atelier.png" title="Menuiserie et agencement Lozère"/>
					</a>
				</div> -->
			    <ul class="menu flex-container flex-justify-center">
						<li><a href="http://www.lesateliersdubes.fr " title="Menuiserie et agencement Lozère"><img src="/theme/default/img/icone_home.png" title="Accueil" title="Menuiserie et agencement Lozère"/></a></li>
						<li><a class=" art72 ord1" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/3-escaliers-bois-traditionnel-contemporain.php">Escaliers</a></li><li><a class=" art72 ord2" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/4-menuiserie-porte-meuble.php">Menuiserie</a></li><li><a class=" art72 ord3" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/71-amenagement-cuisine-lozere.php">Cuisine</a></li><li><a class=" art72 ord4" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/5-amenagement-dressing-rangement.php">Am&eacute;nagement</a></li><li><a class=" art72 ord5 selected" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/72-agencemenent-professionnel-lozere-cantal-aveyron.php">Pour les pros</a></li><li><a class=" art72 ord6" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/7-terrasse-bois-architecture.php">Terrasse bois</a></li><li><a class=" art72 ord7" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/6-patrimoine-architecture-lozere-aveyron.php">Patrimoine</a></li><li><a class=" art72 ord8" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/amenagement-menuisier-aubrac/73-metallerie.php">M&eacute;tallerie</a></li>            	</ul>
       		</div>

			<div class="border-head"></div>
			<!-- 			
							
			             -->

            <div class="content pal">
														<div class="bab-gallery"><div class="swiper-container"><div class="swiper-wrapper"><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/voltigeuses-14-final-bis.-014705.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/voltigeuses-16-final.-014714.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/voltigeuses-18-final.-014722.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/voltigeuses-32-final.-014729.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/amenagement1.-025109.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/amenagement3.-025115.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/img-2709.-025145.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/img-2935.-025225.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/resized-20180705-200922.-092438.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/resized-20180705-200257.-092451.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/resized-20180705-200341.-092500.jpg" alt="" /></div><div class="swiper-slide"><img src="/upload/galeries/galerie9/maxi/resized-20180705-200536.-092509.jpeg" alt="" /></div></div><div class="swiper-pagination"></div></div></div><div class="bab_contenu_article"><h1>Agencement professionnel</h1><p>Les Ateliers du B&egrave;s r&eacute;alisent vos agencements professionnels sur mesure pour tous types de locaux :</p>
<ul>
<li>commerces et boutiques</li>
<li>h&ocirc;tels et restaurants</li>
<li>bureaux</li>
</ul>
<p>Types d'am&eacute;nagements notamment propos&eacute;s :</p>
<ul>
<li>parquet et claustras</li>
<li>pr&eacute;sentoirs et rayonnages</li>
<li>bureaux et banque d'accueil</li>
<li>am&eacute;nagement complet de magasin</li>
<li></li>
</ul>
<p>Si la zone d'intervention privil&eacute;gi&eacute;e des Ateliers du B&egrave;s demeure la Loz&egrave;re, l'Aveyron et le Cantal, la soci&eacute;t&eacute; n'h&eacute;site pas &agrave; se d&eacute;placer dans toute la France quand il s'agit de la r&eacute;alisation globale d'un agencement professionnel original et de qualit&eacute;.</p><div class="clear"></div></div>
							<footer class="">
								<div class="grid-3 flex-align-center">
									<div class="txtcenter">
										<a id="ask-devis" class="btn" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/13-contact-acces.php">Demande de devis gratuit</a>
									</div>
									<div class="txtcenter">
										<span id="target" class="btn" href="">
											<span class="title">Téléphone</span>
											<a href="tel:+33 (0)4 66 45 90 54">+33 (0)4 66 45 90 54</a></span>
									</div>
									<div class="txtcenter">
										<a id="contact" class="btn" href="/fr/menuiserie-escalier-lozere-aveyron-cantal/13-contact-acces.php">Contact</a>
									</div>
								</div>
								
								<address class="txtcenter">
									<span class="adrr">Les Ateliers du Bès  |  Route d’Aubrac - 48260 Nasbinals - Lozère  |  FRANCE  </span>
								</address>

							</footer>
           	</div>

            <div class="footer txtcenter"><a href="/fr/menuiserie-escalier-lozere-aveyron-cantal/menuisier-lozere-aveyron-cantal/9-artisan-menuisier.php">Artisan-menuisier</a> | <a href="/fr/menuiserie-escalier-lozere-aveyron-cantal/menuisier-lozere-aveyron-cantal/10-liens-partenaires.php">Liens &amp; partenaires</a> | <a href="/fr/menuiserie-escalier-lozere-aveyron-cantal/menuisier-lozere-aveyron-cantal/14-mentions-legales.php">Mentions l&eacute;gales</a>

            </div>

        </div>
    <span id="stamp"><a title="Création et hébergement de sites internet à Pontarlier, Besançon et Morteau, dans le Doubs, le Jura, la Franche-Comté et en Alsace" target="_blank" href="http://www.cyberiance.com" >Création site Cyberiance</a></span>
	</body>
   <script type="text/javascript">
	$(document).ready(function() {
		$(".fancybox").fancybox({
			padding : 2
		});

		$('#target').click(function(){
			$('#target .title').css('display', 'none');
			$('#target a').css('display','inline-block');
		});

		var mySwiper = new Swiper ('.swiper-container', {
      // Optional parameters
			slidesPerView : 'auto',
			effect :'fade',
			grabCursor : true,
			autoplay : true,
			speed : 800,
			pagination: {
    		el : '.swiper-pagination',
    		type : 'bullets',
				clickable : true,
				hideOnClick : true,
				bulletActiveClass : 'swiper-pagination-bullet-active-green'
  		},

		})

	});
</script>
</html>
